import { combineReducers } from 'redux'
import {TOGGLE_ACTIVE, FILTER, FILTER_DETAILS, START_LOADING, STOP_LOADING, ADD_DATA} from '../Constants'

let gridRecords = [
        {firstName: "John", lastName: "Doe", active: false, id: 1},
        {firstName: "Mary", lastName: "Moe", active: false, id: 2},
        {firstName: "Peter", lastName: "Noname", active: true, id: 3}
    ],
    detailsRecords = [{
        id:1,
        name:"John Doe",
        about:"Nice guy",
        hobby:"Likes drinking wine",
        skills:["html", "javascript", "redux"]
    },{
        id:2,
        name:"Mary Moe",
        about:"Cute girl",
        hobby:"Likes playing xbox whole days long",
        skills:["Fortran", "Lua", "R#"]
    },{
        id:3,
        name:"Peter Noname",
        about:"guy guy",
        hobby:"Likes horse",
        skills:["javascript", "Lua", "Fortran"]
    }];

let gridState = {
    records:[],
    filtered: [],
    loading:false
}
export function grid(state = gridState, action) {
    switch (action.type) {
        case
        START_LOADING:
            return Object.assign({}, state, {loading: true});
        case
        STOP_LOADING:
            return Object.assign({}, state, {loading: false});
        case
        ADD_DATA:
            return Object.assign({}, state, {
                records: [...action.value]
            });
        case "TOGGLE_ACTIVE":
            let newState = [...state];
            newState[action.value].active = !newState[action.value].active;
            return newState;
        case "FILTER":
            let value = action.value,
                newRecords = gridRecords.filter((record) => record.firstName.toUpperCase().includes(value.toUpperCase()));
            return newRecords;
        default:
            return state
    }
}


export function details(state = detailsRecords, action){
    switch (action.type) {
        case "FILTER_DETAILS":
            let id = action.value;
            if (id) {
                return detailsRecords.filter((record) => {
                    return record.id == id;
                })
            } else {
                return detailsRecords
            }
        default:
            return state
    }
}

export const rootReducer = combineReducers({
    details,
    grid
});