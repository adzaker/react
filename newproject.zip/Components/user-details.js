import React from 'react';
import PropTypes from 'prop-types';
import UserDetail from './user-detail';
import { connect } from 'react-redux';
import {filterDetails} from '../Actions'

class UserDetails extends React.Component {
    filterDetails(id) {
        let {dispatch} = this.props;
        dispatch(filterDetails(this.props.match.params.id));
    }
    componentWillMount() {
        this.filterDetails(this.props.match.params.id);
    }
/*    componentWillReceiveProps(props){
        if (props.match.params.id){
            this.filterDetails(props.match.params.id);
        } else {
            this.filterDetails(false);
        }
    }*/
    componentWillUpdate(props){
        if (props.match.params.id == undefined){
            this.filterDetails(false);
        }
    }
    componentDidMount(){
        if (this.props.match.params.id == undefined){
            this.filterDetails(false);
        }
    }
    render(){
        let details = this.props.details.map((detail, index)=>{
            return <UserDetail key={index} detail={detail} />
        });
        return (
        <div className="container">
            <div className="row">
                <div className="col-md-offset-2 col-md-8 col-lg-offset-3 col-lg-6">
                    {details}
                </div>
            </div>
        </div>
        );
    }
}

UserDetails.propTypes = {
    details: PropTypes.array.isRequired
};

function mapStateToProps(state) {
    return {
        details: state.details
    }
}

export default connect(
    mapStateToProps
)(UserDetails)
