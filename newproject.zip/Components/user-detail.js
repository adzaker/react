import React from 'react';

export default class userDetail extends React.Component {
    render(){
        let {detail} = this.props;
        let skills = detail.skills.map((skill, index)=>{
            return <span className="tags" key={index}>{skill} </span>
        });

        return (

        <div className="well profile">
            <div className="col-sm-12">
                <div className="col-xs-12 col-sm-8">
                    <h2>{detail.name}</h2>
                    <p><strong>About: </strong> {detail.about} </p>
                    <p><strong>Hobbies: </strong> {detail.hobby} </p>
                    <p>
                        <strong>Skills: </strong>
                        {skills}
                    </p>
                </div>
                <div className="col-xs-12 col-sm-4 text-center">
                    <figure>
                    <img src="http://www.bitrebels.com/wp-content/uploads/2011/02/Original-Facebook-Geek-Profile-Avatar-2.jpg" alt="" class="img-circle img-responsive"/>
                    </figure>
                </div>
            </div>
        </div>
    )
    }
}